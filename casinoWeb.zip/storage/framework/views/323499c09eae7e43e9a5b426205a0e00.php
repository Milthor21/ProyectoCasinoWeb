<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/img/Logo.png" />
    <title>Casino | <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Arimo:ital,wght@0,400..700;1,400..700&display=swap" rel="stylesheet">
    <link href="/css/styles.css" rel="stylesheet">
    <?php echo $__env->yieldPushContent('script'); ?>
</head>
<body>
    <div class="nav-bg">
        <nav class="navegacion-principal">
            <img src="/img/Logo2.png" alt="">
            <a href="/">Inicio</a>
            <a href="jugar">Jugar</a>
            <a href="creditos">Creditos</a>
            <?php if(auth()->guard()->check()): ?>
                <form class="boton2" action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="Logout">
                </form>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                <a href="/login">Login</a>
            <?php endif; ?>
    </div>
    <?php echo $__env->yieldContent('content'); ?>

    <footer class="footer">
        <p>&copy; Todos los derechos reservados 2024</p>
    </footer>
   
</body>
</html><?php /**PATH C:\Users\macma\OneDrive - Universidad de Sonsonate\Documentos\CICLO-01-2024-USO\redes_II_2024\casino_web\ProyectoCasinoWeb\resources\views/app.blade.php ENDPATH**/ ?>