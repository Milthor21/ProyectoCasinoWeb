<?php $__env->startSection('title'); ?>
    Inicio
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main id="inicio" style="flex-grow: 1">
    <div class="index_banner">
        <img src="<?php echo e(asset('img/banner_ruleta.png')); ?>" alt="">
    </div>
    <H2>Ruleta de la fortuna</H2>
    <div class="ruleta">
        <img class="ruleta_img" src="img/rulet.png" alt="">
        <div class="top">
            <h1>Top 20 mejores jugadores</h1>
            <ul>
                <?php $__currentLoopData = $topUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($user->name); ?> <span><?php echo e($user->credito); ?></span></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <div class="btn-centrar">
        <a href="<?php echo e(route('jugar')); ?>" class="boton btn2">Jugar</a>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\macma\OneDrive - Universidad de Sonsonate\Documentos\CICLO-01-2024-USO\redes_II_2024\jugar\resources\views/welcome.blade.php ENDPATH**/ ?>