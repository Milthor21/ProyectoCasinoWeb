<?php $__env->startSection('title'); ?>
    Jugar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <main class="center">
        <div class="contenedorCre">
       

            <h1>Creditos</h1>
            <div class="campo-creditos">
                <label>Tus Creditos </label>
                <span class="input-text"><?php echo e(auth()->user()->credito); ?></span>
            </div>
            <div class="opciones">
                <?php $__currentLoopData = $creditos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                    <form action="<?php echo e(route('jugar')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <img src="/img/<?php echo e($credito->imagen); ?>">
                        <input type="hidden" name="cantidad" value="<?php echo e($credito->cantidad); ?>">
                        <input class="boton" type="submit" value="Comprar">
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\macma\OneDrive - Universidad de Sonsonate\Documentos\CICLO-01-2024-USO\redes_II_2024\jugar\resources\views/creditos.blade.php ENDPATH**/ ?>