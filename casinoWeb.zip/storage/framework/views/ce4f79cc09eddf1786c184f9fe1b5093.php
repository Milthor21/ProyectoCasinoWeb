<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="center">
    <form class="formulario" method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>
        <fieldset>
            <img src="../img/Logo.png">
            <div class="contenedor-campos">
                <div class="campo">
                    <label>Usuario</label>
                    <input class="input-text" type="text" placeholder="Nombre" name="name" value="<?php echo e(old('name')); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="campo">
                    <label>Correo</label>
                    <input class="input-text" type="email"  placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="campo">
                    <label>Contraseña</label>
                    <input class="input-text" type="password"  placeholder="********" name="password" value="<?php echo e(old('password')); ?>">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="campo">
                    <label>Repita  Contraseña</label>
                    <input class="input-text" type="password"  placeholder="********" name="password_confirmation">
                </div>
            </div> <!-- .contenedor-campos -->
            <div class="Registrarse">
                <div>
                    <input class="boton " type="submit" value="Registrarse">
                </div>
                
            </div>
        </fieldset>
    </form>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Casa_\OneDrive\Escritorio\casino\resources\views/auth/register.blade.php ENDPATH**/ ?>