<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="center">
    <form class="formulario" method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <fieldset>
            <img src="/img/Logo.png">
            <div class="contenedor-campos">
                    
                <div class="campo">
                    <label>Correo</label>
                    <input class="input-text" type="email"  placeholder="Email" name="email">
                </div>
                <div class="campo">
                    <label>Contraseña</label>
                    <input class="input-text" type="password"  placeholder="********" name="password">
                </div>
                
            </div> <!-- .contenedor-campos -->
            <div class="Registrarse">
                <div>
                    <input class="boton" type="submit" value="Iniciar sesión">
                </div>
                
            </div>
        </fieldset>
        <div class="Registro">
            <label>¿No tienes una cuenta? Registrate aqui</label>
            <a href="/registrarse">Registrarse</a></div>
    </form>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\macma\OneDrive - Universidad de Sonsonate\Documentos\CICLO-01-2024-USO\redes_II_2024\jugar\resources\views/auth/login.blade.php ENDPATH**/ ?>