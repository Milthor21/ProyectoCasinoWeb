<?php $__env->startSection('title'); ?>
    Inicio
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main id="inicio" style="flex-grow: 1">
    <div class="index_banner">
        <img src="<?php echo e(asset('img/banner_ruleta.png')); ?>" alt="">
    </div>
    <H2>Ruleta de la fortuna</H2>
    <div class="ruleta">
        <img class="ruleta_img" src="img/rulet.png" alt="">
        <img class="ruleta_banner" src="img/POSTER.png" alt="">
    </div>
    <div class="btn-centrar">
        <a href="jugar/jugar.html" class="boton btn2">Jugar</a>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Casa_\OneDrive\Escritorio\casino\resources\views/welcome.blade.php ENDPATH**/ ?>